# Ada's Eyrie Repo

Wherein I set up a little space for myself on the web, and learn a bunch of stuff as I go.

## Installation

```
brew install vagrant hatch poetry
brew install --cask virtualbox
vagrant up eyrie-dev
```